const Upcoming = () => {
    return(
       <p>This is the Upcoming content</p> 
    )
}

export default Upcoming 