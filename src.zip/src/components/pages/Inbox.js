

const Inbox = () => {
    
    return (
    <>
    Inbox Content
    </>
    )
}

export default Inbox